#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall as4-crypto-operations -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





