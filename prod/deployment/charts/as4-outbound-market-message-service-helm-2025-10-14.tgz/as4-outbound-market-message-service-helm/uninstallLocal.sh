#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall as4-outbound-market-message-service -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





