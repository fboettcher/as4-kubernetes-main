#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall as4-inbound-endpoint -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





