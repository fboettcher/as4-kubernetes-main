#!/bin/bash

KUBERNERNETES_NAMESPACE=b2b

helm uninstall fss -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





