#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall as4-outbound-sender -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





