#!/bin/bash

#abort on first error
set -e

# Script configuration
# ACR RTE Registry (...)
DOCKER_REGISTRY_IMAGE_PULL_HOSTNAME="devnortheuropemgmtacr.azurecr.io"
DOCKER_REGISTRY_IMAGE_PULL_USERNAME="crypto-reader"
DOCKER_REGISTRY_IMAGE_PULL_SECRET="mako-cloud-registry"

KUBERNETES_NAMESPACE=crypto

echo "using namespace $KUBERNETES_NAMESPACE"
kubectl config use-context docker-desktop

# Preparing image pull secret for RTE ACR
CURRENT_SECRET_FOR_NAMESPACE_SERVICEACCOUNT=$(kubectl describe serviceaccount default --namespace=$KUBERNETES_NAMESPACE | grep 'Image pull secrets' | sed -n 's/.*:  \(.*\)/\1/p')
if [ "$CURRENT_SECRET_FOR_NAMESPACE_SERVICEACCOUNT" != $DOCKER_REGISTRY_IMAGE_PULL_SECRET ]
then
  echo "Enter password for docker registry user $DOCKER_REGISTRY_IMAGE_PULL_HOSTNAME/$DOCKER_REGISTRY_IMAGE_PULL_USERNAME:"
  read -s DOCKER_REGISTRY_IMAGE_PULL_PASSWORD
  echo "Performing docker login to validate credentials"
  echo $DOCKER_REGISTRY_IMAGE_PULL_PASSWORD | docker login -u=$DOCKER_REGISTRY_IMAGE_PULL_USERNAME --password-stdin $DOCKER_REGISTRY_IMAGE_PULL_HOSTNAME

  NAMESPACE_EXISTS=$(kubectl get namespace $KUBERNETES_NAMESPACE --ignore-not-found);
  if [[ "$NAMESPACE_EXISTS" ]]; then
    echo "namespace $KUBERNETES_NAMESPACE already exists"
  else
    echo "Creating namespace $KUBERNETES_NAMESPACE";
    kubectl create namespace $KUBERNETES_NAMESPACE;
  fi;
  echo "Creating image pull secret in kubernetes"
  kubectl delete secret $DOCKER_REGISTRY_IMAGE_PULL_SECRET --ignore-not-found --namespace=$KUBERNETES_NAMESPACE
  kubectl create secret docker-registry $DOCKER_REGISTRY_IMAGE_PULL_SECRET --docker-server=$DOCKER_REGISTRY_IMAGE_PULL_HOSTNAME --docker-username=$DOCKER_REGISTRY_IMAGE_PULL_USERNAME --docker-password=$DOCKER_REGISTRY_IMAGE_PULL_PASSWORD --namespace=$KUBERNETES_NAMESPACE
  echo "Patching default service account to use created secret"
  kubectl patch serviceaccount default --patch="{\"imagePullSecrets\": [{\"name\": \"$DOCKER_REGISTRY_IMAGE_PULL_SECRET\"}]}" --namespace=$KUBERNETES_NAMESPACE
fi

  echo helm upgrade certificate-manager . -n $KUBERNETES_NAMESPACE --create-namespace --install
  helm upgrade certificate-manager . -n $KUBERNETES_NAMESPACE --create-namespace  --install