#!/bin/bash

KUBERNETES_NAMESPACE=crypto

helm uninstall certificate-manager -n $KUBERNETES_NAMESPACE --kube-context docker-desktop
