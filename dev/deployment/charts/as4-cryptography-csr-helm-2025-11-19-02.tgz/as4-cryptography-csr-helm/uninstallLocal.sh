#!/bin/bash

KUBERNERNETES_NAMESPACE=crypto

helm uninstall as4-cryptography-csr -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





