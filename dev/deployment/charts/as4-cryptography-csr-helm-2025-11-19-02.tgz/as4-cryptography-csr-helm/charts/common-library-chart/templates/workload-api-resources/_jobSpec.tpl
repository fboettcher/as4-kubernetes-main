{{/* vim: set filetype=mustache: */}}
{{- define "common.jobSpec.v1.0.15" -}}

{{- with .Values.suspend | default false }}
suspend: {{ . }}
{{- end }}
template: {{ include "common.podTemplateSpec.v1.0.15" . | nindent 6 }}    
{{- end }}