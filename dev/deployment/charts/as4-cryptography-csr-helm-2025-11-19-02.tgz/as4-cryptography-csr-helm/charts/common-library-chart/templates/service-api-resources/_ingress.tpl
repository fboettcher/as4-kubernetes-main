{{/* vim: set filetype=mustache: */}}
{{- define "common.classes.ingress.v1.0.15" -}}

{{- $values := .values -}}
{{- $context := .context -}}
{{- $serviceName := $values.serviceName | default (include "common.names.fullname.v1.0.15" .context) -}}
{{- $servicePort := $values.servicePort | default .context.Values.service.port.port -}}
{{- $name := include "common.names.fullname.v1.0.15" .context -}}
{{- $nameSuffix := .context.Values.nameSuffix | default "" -}}
{{- if $nameSuffix }}
  {{- $name = printf "%v-%v" $name $nameSuffix -}}
{{- end -}}

apiVersion: {{ include "common.capabilities.ingress.apiVersion.v1.0.15" .context }}
kind: Ingress
metadata:
  name: {{ $name }}
  namespace: {{ .context.Release.Namespace | quote }}
  labels:
    {{- include "common.labels.v1.0.15" .context | nindent 4 }}
  {{- with .context.Values.commonLabels }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with $values.labels }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  annotations:
  {{- with .context.Values.commonAnnotations }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with $values.annotations }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- if and (eq (include "common.capabilities.ingress.apiVersion.v1.0.15" .context) "networking.k8s.io/v1") (not (empty $values.ingressClassName)) }}
  ingressClassName: {{ $values.ingressClassName }}
  {{- end }}
  rules:
  {{- range $values.hosts }}
  - host: {{ tpl .host $context | quote }}
    http:
      paths:
        {{- range .paths }}
        - path: {{ tpl .path $context | quote }}
          {{- if eq (include "common.capabilities.ingress.apiVersion.v1.0.15" $context) "networking.k8s.io/v1" }}
          pathType: {{ default "Prefix" .pathType }}
          {{- end }}
          backend:
          {{- if eq (include "common.capabilities.ingress.apiVersion.v1.0.15" $context) "networking.k8s.io/v1" }}
            service:
              name: {{ .serviceName | default $serviceName }}
              port:
                number: {{ .servicePort | default $servicePort }}
          {{- else }}
            serviceName: {{ .serviceName | default $serviceName }}
            servicePort: {{ .servicePort | default $servicePort }}
          {{- end }}
        {{- end }}
  {{- end }}
  {{- if $values.tls }}
  tls:
    {{- range $values.tls }}
    - hosts:
        {{- range .hosts }}
        - {{ tpl . $ | quote }}
        {{- end }}
      {{- if .secretName }}
      secretName: {{ tpl .secretName $ | quote}}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
