{{/* vim: set filetype=mustache: */}}
{{- define "common.podSpec.v1.0.15" -}}

{{- $context := $ -}}
{{- if (not (empty .Values.image.pullSecret)) }}
{{- with .Values.image.pullSecret }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}
serviceAccountName: {{ include "common.names.serviceAccountName.v1.0.15" . }}
{{- with .Values.podSecurityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.priorityClassName }}
priorityClassName: {{ . }}
{{- end }}
{{- with .Values.schedulerName }}
schedulerName: {{ . }}
{{- end }}
{{- with .Values.restartPolicy | default "Always" }}
restartPolicy: {{ . }}
{{- end }}
{{- with .Values.hostNetwork }}
hostNetwork: {{ . }}
{{- end }}
{{- with .Values.hostname }}
hostname: {{ . }}
{{- end }}
{{- if .Values.dnsPolicy }}
dnsPolicy: {{ .Values.dnsPolicy }}
{{- else if .Values.hostNetwork }}
dnsPolicy: "ClusterFirstWithHostNet"
{{- else }}
dnsPolicy: ClusterFirst
{{- end }}
{{- with .Values.dnsConfig }}
dnsConfig:
  {{- toYaml . | nindent 2 }}
{{- end }}
enableServiceLinks: {{ .Values.enableServiceLinks }}
{{- with .Values.initContainers }}
initContainers:
  {{- range . }}
  - {{ tpl (toYaml .) $ | nindent 4 }}
  {{- if $.Values.env }}
    env:
    {{- range $key, $value := $.Values.env }}
    - name: {{ $key }}
      value: {{ tpl $value $ | quote }}
    {{- end }}
  {{- end }}
  {{- if $.Values.envFrom }}
    envFrom:
    {{- with $.Values.envFrom }}
      {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- end }}
{{- end }}
containers: {{ include "common.container.v1.0.15" . }}
  {{- with .Values.extraContainers }}
    {{- tpl (toYaml .) $ }}
  {{- end }}
{{- with (include "common.volumes.v1.0.15" . | trim) }}
volumes:
  {{- . | nindent 0 }}
{{- end }}
{{- with .Values.hostAliases }}
hostAliases:
{{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}
