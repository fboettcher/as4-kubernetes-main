{{/* vim: set filetype=mustache: */}}

{{- define "common.mountFiles.v1.0.15" -}}

{{- $chartName := .Chart.Name -}}
{{- range .Values.mountFiles }}
{{- if  (eq .type "ConfigMap") }}
{{ print "---" | nindent 0 }}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $chartName }}-{{ .name }}-configmap
  labels:
      {{- include "common.labels.v1.0.15" $ | nindent 4 }}
binaryData:
  {{ .podMountFileName }}:  {{ tpl ($.Files.Get .localFile) $ | b64enc }}
{{- end }}
{{- if  (eq .type "Secret") }}
{{ print "---" | nindent 0 }}
apiVersion: v1
kind: Secret
metadata:
  name: {{ $chartName }}-{{ .name }}-secret
  labels:
      {{- include "common.labels.v1.0.15" $ | nindent 4 }}
data:
  {{ .podMountFileName }}:  {{ tpl ($.Files.Get .localFile) $ | b64enc }}
{{- end }}
{{- end }}
{{- end }}