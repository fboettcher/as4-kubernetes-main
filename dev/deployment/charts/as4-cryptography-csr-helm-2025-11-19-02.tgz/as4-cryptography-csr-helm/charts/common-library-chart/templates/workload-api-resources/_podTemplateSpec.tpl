{{/* vim: set filetype=mustache: */}}
{{- define "common.podTemplateSpec.v1.0.15" -}}

{{- $context := $ -}}
metadata:
    {{- with .Values.podAnnotations }}
    annotations:
    {{- toYaml . | nindent 8 }}
    {{- end }}
    labels:
    {{- if .Values.forcePodRecreationOnHelmUpdate }}
        rollme: {{ randAlphaNum 5 | quote }}
    {{- end }}
    {{- include "common.labels.selectorLabels.v1.0.15" . | nindent 8 }}
spec: {{ include "common.podSpec.v1.0.15" . | indent 4 }}    
{{- end }}
