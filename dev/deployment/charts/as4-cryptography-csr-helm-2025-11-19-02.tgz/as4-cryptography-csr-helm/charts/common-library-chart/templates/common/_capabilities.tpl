{{/* vim: set filetype=mustache: */}}
{{/* https://kubernetes.io/docs/reference/using-api/deprecation-guide/ */}}

{{/* Return the appropriate apiVersion for daemonset. */}}
{{- define "common.capabilities.daemonset.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.9.0" .Capabilities.KubeVersion.Version -}}
{{- print "extensions/v1beta1" -}}
{{- else -}}
{{- print "apps/v1" -}}
{{- end -}}
{{- end -}}

{{/* Return the appropriate apiVersion for deployment. */}}
{{- define "common.capabilities.deployment.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.9.0" .Capabilities.KubeVersion.Version -}}
{{- print "extensions/v1beta1" -}}
{{- else -}}
{{- print "apps/v1" -}}
{{- end -}}
{{- end -}}

{{/* Return the appropriate apiVersion for statefulset. */}}
{{- define "common.capabilities.statefulset.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.9.0" .Capabilities.KubeVersion.Version -}}
{{- print "apps/v1beta1" -}}
{{- else -}}
{{- print "apps/v1" -}}
{{- end -}}
{{- end -}}

{{/* Return the appropriate apiVersion for job. */}}
{{- define "common.capabilities.job.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.21.0" .Capabilities.KubeVersion.Version -}}
{{- print "batch/v1beta1" -}}
{{- else -}}
{{- print "batch/v1" -}}
{{- end -}}
{{- end -}}

{{/* Return the appropriate apiVersion for cronjob. */}}
{{- define "common.capabilities.cronjob.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.21.0" .Capabilities.KubeVersion.Version -}}
{{- print "batch/v1beta1" -}}
{{- else -}}
{{- print "batch/v1" -}}
{{- end -}}
{{- end -}}

{{/* Return the appropriate apiVersion for ingress. */}}
{{- define "common.capabilities.ingress.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.9.0" .Capabilities.KubeVersion.Version -}}
{{- print "extensions/v1beta1" -}}
{{- else if semverCompare "<1.19.0" .Capabilities.KubeVersion.Version -}}
{{- print "networking.k8s.io/v1beta1" -}}
{{- else -}}
{{- print "networking.k8s.io/v1" -}}
{{- end }}
{{- end -}}

{{/* Return the appropriate apiVersion for network policy. */}}
{{- define "networkPolicy.apiVersion.v1.0.15" -}}
{{- if semverCompare "<1.14-0" .Capabilities.KubeVersion.Version -}}
{{- print "extensions/v1beta1" -}}
{{- else if semverCompare "<1.19-0" .Capabilities.KubeVersion.Version -}}
{{- print "networking.k8s.io/v1beta1" -}}
{{- else -}}
{{- print "networking.k8s.io/v1" -}}
{{- end }}
{{- end -}}