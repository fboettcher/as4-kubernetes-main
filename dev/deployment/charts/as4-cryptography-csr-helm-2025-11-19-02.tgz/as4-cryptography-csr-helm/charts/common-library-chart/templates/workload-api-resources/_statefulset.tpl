{{/* vim: set filetype=mustache: */}}
{{- define "common.statefulset.v1.0.15" -}}

apiVersion: {{ include "common.capabilities.statefulset.apiVersion.v1.0.15" . }}
kind: StatefulSet
metadata: {{ include "common.objectmeta.v1.0.15" $ | nindent 2 }}
spec:
  {{- if and .Values.replicaCount (not .Values.autoscaling.enabled) }}
  replicas: {{ .Values.replicaCount }}
  {{- end }}
  {{- with .Values.strategy }}
  updateStrategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.15" . | nindent 6 }}
  serviceName: {{ include "common.names.fullname.v1.0.15" . }}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
      {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        {{- if .Values.forcePodRecreationOnHelmUpdate }}
        timestamp: "{{ date "20060102150405" now }}"
        {{- end }}
      {{- include "common.labels.selectorLabels.v1.0.15" . | nindent 8 }}
    spec:
      {{- include "common.podSpec.v1.0.15" . | nindent 6 }}
  volumeClaimTemplates:
  {{- range $index, $vct := .Values.volumeClaimTemplates }}
  - metadata:
      name: {{ $vct.name }}
    spec:
      accessModes:
        - {{ required (printf "accessModes is required for vCT %v" $vct.name) $vct.accessModes  | quote }}
      resources:
        requests:
          storage: {{ required (printf "size is required for PVC %v" $vct.name) $vct.size | quote }}
      {{- if $vct.storageClass }}
      storageClassName: {{ if (eq "-" $vct.storageClass) }}""{{- else }}{{ $vct.storageClass | quote }}{{- end }}
      {{- end }}
      {{- with $vct.volumeMode }}
      volumeMode: {{ . | quote }}
      {{- end }}
      {{- with $vct.volumeName }}
      volumeName: {{ . | quote }}
      {{- end }}
{{- end }}

{{- end }}
