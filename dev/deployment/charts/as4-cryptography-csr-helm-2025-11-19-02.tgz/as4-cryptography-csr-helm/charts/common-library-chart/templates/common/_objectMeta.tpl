{{/* vim: set filetype=mustache: */}}
{{- define "common.objectmeta.v1.0.15" -}}

{{- $name := include "common.names.fullname.v1.0.15" . -}}
{{- $nameSuffix := .Values.nameSuffix | default "" -}}
{{- if $nameSuffix }}
  {{- $name = printf "%v-%v" $name $nameSuffix -}}
{{- end -}}
name: {{ $name }}
namespace: {{ .Release.Namespace | quote }}
labels:
  {{- include "common.labels.v1.0.15" . | nindent 4 }}
{{- with .Values.commonLabels }}
  {{- toYaml . | nindent 4 }}
{{- end }}
{{- with .Values.commonAnnotations }}
annotations:
  {{- toYaml . | nindent 4 }}
{{- end }}
{{- end }}