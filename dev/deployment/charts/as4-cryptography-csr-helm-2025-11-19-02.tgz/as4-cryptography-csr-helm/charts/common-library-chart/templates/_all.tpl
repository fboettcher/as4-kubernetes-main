{{/* vim: set filetype=mustache: */}}
{{- define "common.all.v1.0.15" -}}

  {{- /* Merge the local chart values and the common chart defaults */ -}}
  {{- include "common.values.v1.0.15" . }}

  {{- $context := $ -}}

  {{- /* Add persistance volume claims */ -}}
  {{- range $storageName, $storage := .Values.storages }}
  {{- if $storage.enabled }}
  {{- if and (eq (default "persistentVolumeClaim" $storage.type) "persistentVolumeClaim") (not $storage.existingClaim) }}
  {{- $values := $storage -}}
  {{- if not $values.nameSuffix -}}
  {{- $_ := set $values "nameSuffix" $storageName -}}
  {{- end -}}
  {{- print ("---") | nindent 0 }}
  {{- include "common.classes.persistentVolumeClaim.v1.0.15" ( dict "values" $values "context" $context ) | nindent 0  }}
  {{- end }}
  {{- end }}
  {{- end }}
  
  {{- print "---" | nindent 0 }}

  {{- /* Add service account */ -}}
  {{ if .Values.serviceAccount}}
  {{ if .Values.serviceAccount.enabled }}
    {{- include "common.serviceAccount.v1.0.15" . | nindent 0 }}
    {{- print "---" | nindent 0 -}}
  {{ end }}
  {{ end }}

  {{- /* Add workload depending on type */ -}}
  {{- if eq .Values.type "deployment" }}
    {{- include "common.deployment.v1.0.15" . | nindent 0 }}
  {{ else if eq .Values.type "daemonset" }}
    {{- include "common.daemonset.v1.0.15" . | nindent 0 }}
  {{ else if eq .Values.type "statefulset"  }}
    {{- include "common.statefulset.v1.0.15" . | nindent 0 }}
  {{ else if eq .Values.type "job"  }}
    {{- include "common.job.v1.0.15" . | nindent 0 }}
  {{ else if eq .Values.type "cronjob"  }}
    {{- include "common.cronjob.v1.0.15" . | nindent 0 }}
  {{- end -}}

  {{- print "---" | nindent 0 }}
  {{- /* Add horizontal pod autoscaler */ -}}
  {{ include "common.classes.hpa.v1.0.15" . | nindent 0 }}
  {{- print "---" | nindent 0 }}

  {{- /* Add service */ -}}
  {{- if .Values.service -}}
  {{- if .Values.service.enabled -}}
    {{- include "common.classes.service.v1.0.15" . | nindent 0 }}
  {{- end }}
  {{- end }}
  {{- range $storageName, $extraService := .Values.extraServices }}
    {{- if $extraService.enabled -}}
      {{- print ("---") | nindent 0 -}}
      {{- $serviceValues := $extraService -}}
      {{- if not $serviceValues.nameSuffix -}}
        {{- $_ := set $serviceValues "nameSuffix" $storageName -}}
      {{ end -}}
      {{- $_ := set $ "ObjectValues" (dict "service" $serviceValues) -}}
      {{- include "common.classes.service.v1.0.15" $ -}}
    {{- end }}
  {{- end }}
  
  {{- print "---" | nindent 0 }}
  
  {{- /* Add ingress */ -}}
  {{ if .Values.ingress }}
  {{ if .Values.ingress.enabled }}
    {{- include "common.classes.ingress.v1.0.15" ( dict "values" .Values.ingress "context" $context ) | nindent 0 }}    
  {{ end }}
  {{ end }}
  {{- range  .Values.extraIngresses }}
    {{- if .enabled -}}
      {{- print ("---") | nindent 0 -}}
      {{- include "common.classes.ingress.v1.0.15" ( dict "values" . "context" $context ) -}}
    {{- end }}
  {{- end }}

  {{- /* Add mount files */ -}}
  {{- if .Values.mountFiles -}}
    {{ include "common.mountFiles.v1.0.15" .  | nindent 0 }}
  {{- end -}}

  {{- /* Add secret */ -}}
  {{- if (not (empty .Values.image.pullSecret)) }}
  {{- with .Values.image.pullSecret }}
    {{- print "---" | nindent 0 -}}
    {{ include "common.imagepullsecret.v1.0.15" ( dict "." . "context" $context ) | nindent 0 }}
  {{- end }}
  {{- end }}

{{- end -}}
