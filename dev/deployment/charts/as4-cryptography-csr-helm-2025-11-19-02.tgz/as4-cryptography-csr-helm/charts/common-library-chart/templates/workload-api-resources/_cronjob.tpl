{{/* vim: set filetype=mustache: */}}
{{- define "common.cronjob.v1.0.15" -}}

apiVersion: {{ include "common.capabilities.cronjob.apiVersion.v1.0.15" . }}
kind: CronJob
metadata: {{ include "common.objectmeta.v1.0.15" $ | nindent 2 }}
spec:
  schedule: {{ .Values.schedule }}
  {{- with .Values.strategy }}
  selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.15" $ | nindent 6 }}
  jobTemplate:
    spec:
      {{- include "common.cronjobSpec.v1.0.15" $ | nindent 6 }}
    {{- end }}
{{- end }}