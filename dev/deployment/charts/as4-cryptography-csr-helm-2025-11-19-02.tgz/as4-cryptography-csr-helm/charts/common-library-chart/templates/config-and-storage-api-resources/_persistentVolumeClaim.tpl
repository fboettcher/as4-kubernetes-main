{{/* vim: set filetype=mustache: */}}
{{- define "common.classes.persistentVolumeClaim.v1.0.15" -}}

{{- $values := .values -}}
{{- $pvcName := include "common.names.fullname.v1.0.15" .context -}}
{{- if hasKey $values "nameSuffix" -}}
  {{- if not (eq $values.nameSuffix "-") -}}
    {{- $pvcName = printf "%v-%v" $pvcName $values.nameSuffix -}}
  {{ end -}}
{{ end -}}

kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: {{ $pvcName }}
  {{- if or $values.skipuninstall $values.annotations }}
  annotations:
    {{- if $values.skipuninstall }}
    "helm.sh/resource-policy": keep
    {{- end }}
    {{- with $values.annotations }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  labels:
  {{- include "common.labels.v1.0.15" .context | nindent 4 }}
spec:
  accessModes:
  {{- range $values.accessModes }}
    - {{ . | quote }}
  {{- end }}
  {{- with $values.dataSource }}
  dataSource: {{ . }}
  {{- end }}
  resources:
    requests:
      storage: {{ $values.size | quote }}
  {{- with $values.selector }}
  selector: {{ . }}
  {{- end }}
  {{- with $values.storageClass }}
  storageClassName: {{ . | quote }}
  {{- end }}
  {{- with $values.volumeMode }}
  volumeMode: {{ . | quote }}
  {{- end }}
  {{- with $values.volumeName }}
  volumeName: {{ . | quote }}
  {{- end }}
{{- end -}}
