{{/* vim: set filetype=mustache: */}}
{{- define "common.deployment.v1.0.15" -}}

apiVersion: {{ include "common.capabilities.deployment.apiVersion.v1.0.15" . }}
kind: Deployment
metadata: {{ include "common.objectmeta.v1.0.15" $ | nindent 2 }}
spec: {{ include "common.deploymentSpec.v1.0.15" $ | nindent 2 }}  
{{- end }}