{{/* vim: set filetype=mustache: */}}
{{- define "common.secret.v1.0.15" -}}

apiVersion: v1
kind: Secret
metadata: {{ include "common.objectmeta.v1.0.15" $ | nindent 2 }}
type: Opaque
{{- with .Values.secret }}
stringData:
  {{- toYaml . | nindent 2 }}
{{- end }}

{{- end }}
