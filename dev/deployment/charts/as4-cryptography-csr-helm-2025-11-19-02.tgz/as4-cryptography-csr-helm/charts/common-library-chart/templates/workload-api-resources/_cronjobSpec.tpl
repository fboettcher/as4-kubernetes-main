{{/* vim: set filetype=mustache: */}}
{{- define "common.cronjobSpec.v1.0.15" -}}

{{- $context := $ -}}
template: {{ include "common.podTemplateSpec.v1.0.15" . | nindent 6 }}    
{{- end }}