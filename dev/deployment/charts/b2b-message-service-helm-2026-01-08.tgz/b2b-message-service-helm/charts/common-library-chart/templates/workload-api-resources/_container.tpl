{{/* vim: set filetype=mustache: */}}
{{- define "common.container.v1.0.19" -}}

{{- $ports := list -}}
{{- with .Values.service -}}
  {{- $serviceValues := deepCopy . -}}
  {{- if .enabled -}}
    {{- $_ := set .port "name" (default "http" .port.name) -}}
    {{- $ports = mustAppend $ports .port -}}
    {{- range $_ := .extraPorts -}}
      {{/* append the additonalPorts for the main service */}}
      {{- $ports = mustAppend $ports . -}}
    {{- end }}
  {{- end }}
  {{- range $_ := .extraServices }}
    {{- if .enabled -}}
      {{- $_ := set .port "name" (required "Missing port.name" .port.name) -}}
      {{- $ports = mustAppend $ports .port }}
      {{- range $_ := .extraPorts -}}
        {{- $ports = mustAppend $ports . -}}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- $servicePort := .Values.service.port.name }}
- name: {{ include "common.names.fullname.v1.0.19" . }}
  image: "{{ tpl .Values.image.repository . }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  {{- with .Values.command }}
  {{- if kindIs "string" . }}
  command: {{ . }}
  {{- else }}
  command:
  {{ toYaml . | nindent 2 }}
  {{- end }}
  {{- end }}
  {{- with .Values.args }}
  {{- if kindIs "string" . }}
  args: {{ . }}
  {{- else }}
  args:
  {{ toYaml . | nindent 2 }}
  {{- end }}
  {{- end }}
  {{- with .Values.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.lifecycle }}
  lifecycle:
    {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- if .Values.env }}
  env:
  {{- if kindIs "map" .Values.env }}
    {{- range $key, $value := .Values.env }}
    - name: {{ $key }}
      value: {{ tpl $value $ | quote }}
    {{- end }}
  {{- else if kindIs "slice" .Values.env }}
    {{- range .Values.env }}
    - name: {{ .name }}
      {{- if hasKey . "valueFrom" }}
      valueFrom:
  {{- toYaml .valueFrom | nindent 8 }}
      {{- else }}
      value: {{ tpl .value $ | quote }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- end }}
  {{- if .Values.envFrom }}
  envFrom:
  {{- with .Values.envFrom }}
    {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- end }}
  {{- if $ports }}
  ports:
  {{- range $_ := $ports }}
  - name: {{ .name }}
    {{- if and .targetPort (kindIs "string" .targetPort) }}
    {{- fail (printf "Our charts do not support named ports for targetPort. (port name %s, targetPort %s)" .name .targetPort) }}
    {{- end }}
    containerPort: {{ .targetPort | default .port }}
    {{- if .protocol }}
    {{- if or ( eq .protocol "HTTP" ) ( eq .protocol "HTTPS" ) ( eq .protocol "TCP" ) }}
    protocol: TCP
    {{- else }}
    protocol: {{ .protocol }}
    {{- end }}
    {{- else }}
    protocol: TCP
    {{- end }}
  {{- end -}}
  {{- end }}
  volumeMounts:
    {{- range $storageName, $storage := .Values.storages }}
    {{- if $storage.enabled }}
    {{- if $storage.mountPath }}
    - mountPath: {{ $storage.mountPath | default (printf "/%v" $storageName) }}
      name: {{ $storageName }}
    {{- if $storage.subPath }}
      subPath: {{ $storage.subPath }}
    {{- end }}
    {{- end }}
    {{- end }}
    {{- end }}

    {{- if .Values.extraVolumeMounts }}
    {{- tpl (toYaml .Values.extraVolumeMounts) . | nindent 4 }}
    {{- end }}

    {{- if .Values.mountFiles -}}
    {{- $chartName := .Chart.Name -}}
    {{- range .Values.mountFiles }}
    - mountPath: {{ .podMountFolder }}/{{ .podMountFileName }}
      name: {{ $chartName }}-{{ .name }}-{{ if  (eq .type "ConfigMap") }}configmap{{else}}secret{{end}}-volume
    {{- if .podReadOnly }}
      readOnly: true
    {{- end }}
      subPath: {{ .podMountFileName }}
    {{- end -}}
    {{- end -}}
    {{- if eq .Values.type "statefulset"  }}
    {{- range $tmp, $volumeClaimTemplate := .Values.volumeClaimTemplates }}
    - mountPath: {{ $volumeClaimTemplate.mountPath }}
      name: {{ $volumeClaimTemplate.name }}
    {{- if $volumeClaimTemplate.subPath }}
      subPath: {{ $volumeClaimTemplate.subPath }}
    {{- end }}
    {{- end }}
  {{- end }}
  {{- with .Values.stdin | default false }}
  stdin: {{ . }}
  {{- end }}
  {{- with .Values.stdinOnce | default false }}
  stdinOnce: {{ . }}
  {{- end }}
  {{- with .Values.tty | default false }}
  tty: {{ . }}
  {{- end }}
  {{- range $probeName, $probe := .Values.probes }}
    {{- if $probe.enabled -}}
      {{- "" | nindent 2 }}
      {{- $probeName }}Probe:
      {{- if $probe.custom -}}
        {{- $probe.spec | toYaml | nindent 4 }}
      {{- else }}
        {{- "tcpSocket:" | nindent 4 }}
          {{- printf "port: %v" $servicePort  | nindent 6 }}
        {{- printf "initialDelaySeconds: %v" $probe.spec.initialDelaySeconds  | nindent 4 }}
        {{- printf "failureThreshold: %v" $probe.spec.failureThreshold  | nindent 4 }}
        {{- printf "timeoutSeconds: %v" $probe.spec.timeoutSeconds  | nindent 4 }}
        {{- printf "periodSeconds: %v" $probe.spec.periodSeconds | nindent 4 }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- with .Values.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}