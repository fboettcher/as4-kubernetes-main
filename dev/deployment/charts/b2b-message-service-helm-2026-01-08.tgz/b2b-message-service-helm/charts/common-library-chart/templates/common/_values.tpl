{{/*
Takes default values from template chart and makes a merge
*/}}
{{- define "common.values.v1.0.19" -}}
  {{- if ( index .Values "common-library-chart" ) -}}
    {{- $defaultValues := deepCopy ( index .Values "common-library-chart" ) -}}
    {{- $userValues := deepCopy (omit .Values "common-library-chart") -}}
    {{- $mergedValues := mustMergeOverwrite $defaultValues $userValues -}}
    {{- $_ := set . "Values" (deepCopy $mergedValues) -}}
  {{- end }}
{{- end }}
