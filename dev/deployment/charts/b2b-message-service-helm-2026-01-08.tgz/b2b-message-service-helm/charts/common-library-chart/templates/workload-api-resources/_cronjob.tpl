{{/* vim: set filetype=mustache: */}}
{{- define "common.cronjob.v1.0.19" -}}

apiVersion: {{ include "common.capabilities.cronjob.apiVersion.v1.0.19" . }}
kind: CronJob
metadata: {{ include "common.objectmeta.v1.0.19" $ | nindent 2 }}
spec:
  {{- with .Values.concurrencyPolicy }}
  concurrencyPolicy: {{ . | quote }}
  {{- end }}
  {{- with .Values.failedJobsHistoryLimit }}
  failedJobsHistoryLimit: {{ . }}
  {{- end }}
  {{- with .Values.schedule }}
  schedule: {{ . | quote }}
  {{- end }}
  {{- with .Values.startingDeadlineSeconds }}
  startingDeadlineSeconds: {{ . }}
  {{- end }}
  {{- with .Values.successfulJobsHistoryLimit }}
  successfulJobsHistoryLimit: {{ . }}
  {{- end }}
  {{- with .Values.timeZone }}
  timeZone: {{ . | quote }}
  {{- end }}
  jobTemplate:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
      {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
      {{- include "common.labels.selectorLabels.v1.0.19" . | nindent 8 }}
    spec: {{ include "common.jobSpec.v1.0.19" . | indent 6 }}   
{{- end }}