{{/* vim: set filetype=mustache: */}}
{{- define "common.daemonset.v1.0.19" -}}

apiVersion: {{ include "common.capabilities.daemonset.apiVersion.v1.0.19" . }}
kind: DaemonSet
metadata: {{ include "common.objectmeta.v1.0.19" $ | nindent 2 }}
spec:
  selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.19" . | nindent 6 }}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
      {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        {{- if .Values.forcePodRecreationOnHelmUpdate }}
        timestamp: "{{ date "20060102150405" now }}"
        {{- end }}
      {{- include "common.labels.selectorLabels.v1.0.19" . | nindent 8 }}
    spec:
      {{- include "common.podSpec.v1.0.19" . | nindent 6 }}
      
{{- end }}
