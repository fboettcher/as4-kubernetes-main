{{/* vim: set filetype=mustache: */}}
{{- define "common.serviceAccount.v1.0.19" -}}

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "common.names.serviceAccountName.v1.0.19" . }}
  labels:
    {{- include "common.labels.v1.0.19" . | nindent 4 }}
  {{- with .Values.serviceAccount.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
automountServiceAccountToken: {{ .Values.serviceAccount.automountServiceAccountToken }}
{{- with .Values.serviceAccount.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}
