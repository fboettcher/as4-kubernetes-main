{{/* vim: set filetype=mustache: */}}
{{- define "common.classes.hpa.v1.0.19" -}}

{{- if .Values.autoscaling }}
{{- if .Values.autoscaling.enabled }}

{{- $targetName := include "common.names.fullname.v1.0.19" . -}}

{{- $name := include "common.names.fullname.v1.0.19" . -}}
{{- $nameSuffix := .Values.nameSuffix | default "" -}}
{{- if $nameSuffix }}
  {{- $name = printf "%v-%v" $name $nameSuffix -}}
{{- end -}}

apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ $name }}
  namespace: {{ .Release.Namespace | quote }}
  labels:
    {{- include "common.labels.v1.0.19" . | nindent 4 }}
  {{- with .Values.commonLabels }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  annotations:
  {{- with .Values.commonAnnotations }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    {{- if eq .Values.type "statefulset" }}
    kind: StatefulSet
    {{- else }}
    kind: Deployment
    {{- end }}
    name: {{ .Values.autoscaling.target | default $targetName }}
  minReplicas: {{ .Values.autoscaling.minReplicas | default 1 }}
  maxReplicas: {{ .Values.autoscaling.maxReplicas | default 3 }}
  metrics:
  {{- if .Values.autoscaling.targetCPUUtilizationPercentage }}
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: {{ .Values.autoscaling.targetCPUUtilizationPercentage }}
  {{- end }}
  {{- if .Values.autoscaling.targetMemoryUtilizationPercentage }}
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: {{ .Values.autoscaling.targetMemoryUtilizationPercentage }}
  {{- end }}
{{- end }}
{{- end }}
{{- end -}}
