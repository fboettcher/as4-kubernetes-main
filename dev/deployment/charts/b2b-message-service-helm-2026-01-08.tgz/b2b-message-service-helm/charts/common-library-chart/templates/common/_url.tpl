{{/* vim: set filetype=mustache: */}}

{{- define "common.url.v1.0.19" -}}
{{- $global := .Values.global -}}
{{- if eq $global.domain "localhost" -}}
{{- printf "%s://localhost" $global.protocol | trimSuffix "-" -}}
{{- else if eq $global.domain "local" -}}
{{- printf "%s://%s-local" $global.protocol .Release.Name | trimSuffix "-" -}}
{{ else -}}
{{- printf "%s://%s-%s.%s" $global.protocol .Release.Name .Release.Namespace $global.domain | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "common.host.v1.0.19" -}}
{{- $global := .Values.global -}}
{{- if eq $global.domain "localhost" -}}
{{- printf "localhost" -}}
{{- else if eq $global.domain "local" -}}
{{- printf "%s-local" .Release.Name | trimSuffix "-" -}}
{{ else -}}
{{- printf "%s-%s.%s" .Release.Name .Release.Namespace $global.domain | trimSuffix "-" -}}
{{- end -}}
{{- end -}}