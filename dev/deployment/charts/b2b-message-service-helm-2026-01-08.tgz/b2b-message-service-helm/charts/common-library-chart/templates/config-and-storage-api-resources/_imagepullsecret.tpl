{{/* vim: set filetype=mustache: */}}
{{/* Create Docker secrets for pulling images from a private container registry. */}}
{{- define "imagePullSecret.auths.v1.0.19" }}
{{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" .registry (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}

{{- define "common.imagepullsecret.v1.0.19" -}}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "common.names.fullname.v1.0.19" .context }}-imagepullsecret
  labels:
    {{- include "common.labels.v1.0.19" .context | nindent 4 }}
type: kubernetes.io/dockerconfigjson
data:
  .dockerconfigjson: {{ include "imagePullSecret.auths.v1.0.19" . }}

{{- end }}
