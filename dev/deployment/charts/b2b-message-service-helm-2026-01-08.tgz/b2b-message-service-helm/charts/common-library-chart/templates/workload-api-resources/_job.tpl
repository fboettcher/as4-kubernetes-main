{{/* vim: set filetype=mustache: */}}
{{- define "common.job.v1.0.19" -}}

apiVersion: {{ include "common.capabilities.job.apiVersion.v1.0.19" . }}
kind: Job
metadata: {{ include "common.objectmeta.v1.0.19" $ | nindent 2 }}
spec:
  {{- include "common.jobSpec.v1.0.19" . | nindent 2 }}   
{{- end }}