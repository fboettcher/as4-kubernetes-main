{{/* vim: set filetype=mustache: */}}
{{- define "common.deployment.v1.0.19" -}}

apiVersion: {{ include "common.capabilities.deployment.apiVersion.v1.0.19" . }}
kind: Deployment
metadata: {{ include "common.objectmeta.v1.0.19" $ | nindent 2 }}
spec: {{ include "common.deploymentSpec.v1.0.19" $ | nindent 2 }}  
{{- end }}