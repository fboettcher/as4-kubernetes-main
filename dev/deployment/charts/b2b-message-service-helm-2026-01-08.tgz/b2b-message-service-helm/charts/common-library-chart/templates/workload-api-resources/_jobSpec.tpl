{{/* vim: set filetype=mustache: */}}
{{- define "common.jobSpec.v1.0.19" -}}

{{- with .Values.activeDeadlineSeconds }}
activeDeadlineSeconds: {{ . }}
{{- end }}
{{- with .Values.backoffLimit }}
backoffLimit: {{ . }}
{{- end }}
{{- with .Values.completionMode }}
completionMode: {{ . | quote }}
{{- end }}
{{- with .Values.suspend | default false }}
suspend: {{ . }}
{{- end }}
{{- with .Values.parallelism }}
parallelism: {{ . }}
{{- end }}
{{- with .Values.ttlSecondsAfterFinished }}
ttlSecondsAfterFinished: {{ . }}
{{- end }}
template: {{ include "common.podTemplateSpec.v1.0.19" . | nindent 6 }}    
{{- end }}