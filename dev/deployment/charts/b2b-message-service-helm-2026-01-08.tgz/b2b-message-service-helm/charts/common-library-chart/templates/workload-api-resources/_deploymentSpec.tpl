{{/* vim: set filetype=mustache: */}}
{{- define "common.deploymentSpec.v1.0.19" -}}

{{- $context := $ -}}
{{- if and .Values.replicaCount (not .Values.autoscaling.enabled) }}
replicas: {{ .Values.replicaCount }}
{{- end }}
{{- with .Values.strategy }}
strategy:
{{- toYaml . | nindent 4 }}
{{- end }}
selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.19" . | nindent 6 }}
{{- with .Values.minReadySeconds | default 0 }}
minReadySeconds: {{ . }}
{{- end }}
{{- with .Values.paused }}
paused: {{ . }}
{{- end }}
{{- with .Values.progressDeadlineSeconds | default 600 }}
progressDeadlineSeconds: {{ . }}
{{- end }}
{{- with .Values.revisionHistoryLimit | default 10 }}
revisionHistoryLimit: {{ . }}
{{- end }}
template: {{ include "common.podTemplateSpec.v1.0.19" . | nindent 6 }}    
{{- end }}
