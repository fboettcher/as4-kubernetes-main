{{/* vim: set filetype=mustache: */}}
{{- define "common.classes.networkpolicy.v1.0.19" -}}

{{- $values := .Values.networkPolicy -}}
{{- $serviceValues := .Values.service -}}
{{- $serviceType := $values.type | default "" -}}
{{- $ports := list -}}
{{- $ports = mustAppend $ports $serviceValues.port -}}
{{- range $_ := $serviceValues.extraPorts -}}
  {{- $ports = mustAppend $ports . -}}
{{- end }}

apiVersion: {{ template "networkPolicy.apiVersion.v1.0.19" . }}
kind: NetworkPolicy
metadata:
  {{ include "common.objectmeta.v1.0.19" $ }}
spec:
  policyTypes:
    - Ingress
  podSelector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.19" . | nindent 6 }}
  ingress:
    {{- if $ports -}}
    ports:
    {{- range $_ := $ports }}
    - port: {{ .port }}
      targetPort: {{ .targetPort | default .name | default "http" }}
      {{- if .protocol }}
      {{- if or ( eq .protocol "HTTP" ) ( eq .protocol "HTTPS" ) ( eq .protocol "TCP" ) }}
      protocol: TCP
      {{- else }}
      protocol: {{ .protocol }}
      {{- end }}
      {{- else }}
      protocol: TCP
      {{- end }}
      name: {{ .name | default "http" }}
      {{- if (and (eq $serviceType "NodePort") (not (empty .nodePort))) }}
      nodePort: {{ .nodePort }}
      {{ end }}
    {{- end -}}
    {{- end -}}
{{- end }}
