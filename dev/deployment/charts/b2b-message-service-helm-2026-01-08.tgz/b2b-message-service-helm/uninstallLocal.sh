#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall b2b-message-service -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





