{{/* vim: set filetype=mustache: */}}
{{- define "common.controller.podSpec.v1.0.0" -}}

{{- $context := $ -}}
{{- if (not (empty .Values.image.pullSecret)) }}
{{- range .Values.image.pullSecret }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}
serviceAccountName: {{ include "common.names.serviceAccountName.v1.0.0" . }}
{{- with .Values.podSecurityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.priorityClassName }}
priorityClassName: {{ . }}
{{- end }}
{{- with .Values.schedulerName }}
schedulerName: {{ . }}
{{- end }}
{{- with .Values.hostNetwork }}
hostNetwork: {{ . }}
{{- end }}
{{- with .Values.hostname }}
hostname: {{ . }}
{{- end }}
{{- if .Values.dnsPolicy }}
dnsPolicy: {{ .Values.dnsPolicy }}
{{- else if .Values.hostNetwork }}
dnsPolicy: "ClusterFirstWithHostNet"
{{- else }}
dnsPolicy: ClusterFirst
{{- end }}
{{- with .Values.dnsConfig }}
dnsConfig:
  {{- toYaml . | nindent 2 }}
{{- end }}
enableServiceLinks: {{ .Values.enableServiceLinks }}
{{- with .Values.initContainers }}
initContainers:
  {{- range . }}
  - {{ toYaml . | nindent 4 }}
  {{- if $.Values.env }}
    env:
    {{- range $key, $value := $.Values.env }}
    - name: {{ $key }}
      value: {{ tpl $value $ | quote }}
    {{- end }}
  {{- end }}
  {{- if $.Values.envFrom }}
    envFrom:
    {{- with $.Values.envFrom }}
      {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- end }}
{{- end }}
containers: {{ include "common.controller.container.v1.0.0" . }}
  {{- with .Values.extraContainers }}
    {{- tpl (toYaml .) $ }}
  {{- end }}
{{- with (include "common.controller.volumes.v1.0.0" . | trim) }}
volumes:
  {{- . | nindent 0 }}
{{- end }}
{{- with .Values.hostAliases }}
hostAliases:
{{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}
