{{/* vim: set filetype=mustache: */}}
{{- define "common.secret.mountFiles.v1.0.0" -}}

{{- $chartName := .Chart.Name -}}
{{- range .Values.mountFiles }}
{{- if  (eq .type "Secret") }}
{{ print "---" | nindent 0 }}

apiVersion: v1
kind: Secret
metadata:
  name: {{ $chartName }}-{{ .name }}-secret
  labels:
      {{- include "common.labels.v1.0.0" $ | nindent 4 }}
data:
  {{ .podMountFileName }}:  {{ tpl ($.Files.Get .localFile) $ | b64enc }}
{{- end }}
{{- end }}
{{- end }}
