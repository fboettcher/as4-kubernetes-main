{{/* vim: set filetype=mustache: */}}
{{- define "common.deployment.v1.0.0" -}}

apiVersion: {{ include "common.capabilities.deployment.apiVersion.v1.0.0" . }}
kind: Deployment
metadata: {{ include "common.objectmeta.v1.0.0" $ | nindent 2 }}
spec:
  replicas: {{ .Values.replicaCount }}
  {{- with .Values.strategy }}
  strategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 6 }}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
      {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        {{- if .Values.forcePodRecreationOnHelmUpdate }}
        rollme: {{ randAlphaNum 5 | quote }}
        {{- end }}
      {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 8 }}
      {{- with .Values.podLabels }}
      {{- toYaml . | nindent 8 }}
      {{- end }}
    spec: {{ include "common.controller.podSpec.v1.0.0" . | nindent 6 }}    
{{- end }}