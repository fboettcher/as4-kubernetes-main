{{/* vim: set filetype=mustache: */}}
{{- define "common.job.v1.0.0" -}}

apiVersion: {{ include "common.capabilities.job.apiVersion.v1.0.0" . }}
kind: Job
metadata: {{ include "common.objectmeta.v1.0.0" $ | nindent 2 }}
spec:
  backoffLimit: {{.Values.backoffLimit }}
  selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 6 }}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
      {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        {{- if .Values.forcePodRecreationOnHelmUpdate }}
        rollme: {{ randAlphaNum 5 | quote }}
        {{- end }}
      {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 8 }}
    spec:
      {{- include "common.controller.podSpec.v1.0.0" . | nindent 6 }}   
{{- end }}