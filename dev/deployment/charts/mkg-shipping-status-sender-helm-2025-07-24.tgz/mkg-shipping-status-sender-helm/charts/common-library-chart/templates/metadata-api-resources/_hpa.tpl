{{/* vim: set filetype=mustache: */}}
{{- define "common.classes.hpa.v1.0.0" -}}

{{- if .Values.autoscaling }}
{{- if .Values.autoscaling.enabled }}

{{- print "---" | nindent 0 -}}
{{- $targetName := include "common.names.fullname.v1.0.0" . -}}

apiVersion: autoscaling/v2beta1
kind: HorizontalPodAutoscaler
metadata:
  {{ include "common.objectmeta.v1.0.0" $ }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    {{- if eq .Values.type "statefulset" }}
    kind: StatefulSet
    {{- else }}
    kind: Deployment
    {{- end }}
    name: {{ .Values.autoscaling.target | default $targetName }}
  minReplicas: {{ .Values.autoscaling.minReplicas | default 1 }}
  maxReplicas: {{ .Values.autoscaling.maxReplicas | default 3 }}
  metrics:
  {{- if .Values.autoscaling.targetCPUUtilizationPercentage }}
    - type: Resource
      resource:
        name: cpu
        targetAverageUtilization: {{ .Values.autoscaling.targetCPUUtilizationPercentage }}
  {{- end }}
  {{- if .Values.autoscaling.targetMemoryUtilizationPercentage }}
    - type: Resource
      resource:
        name: memory
        targetAverageUtilization: {{ .Values.autoscaling.targetMemoryUtilizationPercentage }}
  {{- end }}
{{- end }}
{{- end }}
{{- end -}}
