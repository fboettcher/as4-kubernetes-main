{{/* vim: set filetype=mustache: */}}
{{- define "common.cronjob.v1.0.0" -}}

apiVersion: {{ include "common.capabilities.cronjob.apiVersion.v1.0.0" . }}
kind: CronJob
metadata: {{ include "common.objectmeta.v1.0.0" $ | nindent 2 }}
spec:
  schedule: {{ .Values.schedule }}
  {{- with .Values.strategy }}
  selector:
    matchLabels:
    {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 6 }}
  jobTemplate:
    spec:
      template:
        metadata:
          {{- with .Values.podAnnotations }}
          annotations:
          {{- toYaml . | nindent 8 }}
          {{- end }}
          labels:
            {{- if .Values.forcePodRecreationOnHelmUpdate }}
            rollme: {{ randAlphaNum 5 | quote }}
            {{- end }}
          {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 8 }}
        spec:
          {{- include "common.controller.podSpec.v1.0.0" . | nindent 6 }}
{{- end }}
{{- end }}