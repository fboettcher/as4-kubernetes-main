{{/* vim: set filetype=mustache: */}}
{{- define "common.classes.service.v1.0.0" -}}

{{- $values := .Values.service -}}
{{- $serviceType := $values.type | default "" -}}

{{- $ports := list -}}
{{- $ports = mustAppend $ports $values.port -}}
{{- range $_ := $values.extraPorts -}}
  {{- $ports = mustAppend $ports . -}}
{{- end -}}

{{- $name := include "common.names.fullname.v1.0.0" . -}}
{{- $nameSuffix := .Values.nameSuffix | default "" -}}
{{- if $nameSuffix }}
  {{- $name = printf "%v-%v" $name $nameSuffix -}}
{{- end -}}

apiVersion: v1
kind: Service
metadata:
  name: {{ $name }}
  namespace: {{ .Release.Namespace | quote }}
  labels:
    {{- include "common.labels.v1.0.0" . | nindent 4 }}
  {{- with .Values.commonLabels }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with $values.labels }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  annotations:
  {{- with .Values.commonAnnotations }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with $values.annotations }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  type: {{ $serviceType }}
  {{- if (and (eq $serviceType "ClusterIP") (not (empty $values.clusterIP))) }}
  clusterIP: {{ $values.clusterIP }}
  {{end}}
  {{- if and (eq $serviceType "LoadBalancer") (not (empty $values.loadBalancerIP)) }}
  loadBalancerIP: {{ $values.loadBalancerIP }}
  {{- end }}
  {{- if or (eq $serviceType "LoadBalancer") (eq $serviceType "NodePort") }}
  externalTrafficPolicy: {{ $values.externalTrafficPolicy }}
  {{- end }}
  {{- if and (eq $serviceType "LoadBalancer") (not (empty $values.loadBalancerSourceRanges)) }}
  loadBalancerSourceRanges:
    {{ toYaml $values.loadBalancerSourceRanges | nindent 4 }}
  {{- end -}}
  {{- with $values.externalIPs -}}
  externalIPs:
    {{- toYaml . | nindent 4 -}}
  {{- end }}
  {{- if $values.publishNotReadyAddresses -}}
  publishNotReadyAddresses: {{ $values.publishNotReadyAddresses -}}
  {{- end }}
  {{ if $ports -}}
  ports:
  {{- range $_ := $ports }}
  - name: {{ .name | default "http" }}
    port: {{ .port }}
    targetPort: {{ .targetPort | default .name | default "http" }}
    {{- if or (eq .protocol "HTTP") (eq .protocol "HTTPS") (eq .protocol "TCP") (empty .protocol) }}
    protocol: TCP
    {{- else }}
    protocol: {{ .protocol }}
    {{- end }}
    {{- if and (or (eq $serviceType "NodePort") (eq $serviceType "LoadBalancer")) (not (empty .nodePort)) }}
    nodePort: {{ .nodePort }}
    {{- end }}
  {{ end -}}
  {{ end -}}
  selector:
    {{- include "common.labels.selectorLabels.v1.0.0" . | nindent 4 }}
  {{- if $values.sessionAffinity -}}
  sessionAffinity: {{ $values.sessionAffinity -}}
  {{- if $values.sessionAffinityConfig -}}
  sessionAffinityConfig:
    {{ toYaml $values.sessionAffinityConfig | nindent 4 -}}
  {{- end -}}
  {{- end -}}
{{- end }}