{{/* vim: set filetype=mustache: */}}

{{/* Merge the local chart values and the common chart defaults. */}}
{{- define "common.values.setup.v1.0.0" -}}
  {{- if .Values.common -}}
    {{- $defaultValues := deepCopy .Values.common -}}
    {{- $userValues := deepCopy (omit .Values "common") -}}
    {{- $mergedValues := mustMergeOverwrite $defaultValues $userValues -}}
    {{- $_ := set . "Values" (deepCopy $mergedValues) -}}
  {{- end }}
{{- end }}
