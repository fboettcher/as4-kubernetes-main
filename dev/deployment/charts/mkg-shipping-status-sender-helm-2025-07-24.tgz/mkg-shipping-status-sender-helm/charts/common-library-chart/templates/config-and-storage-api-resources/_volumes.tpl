{{/* vim: set filetype=mustache: */}}
{{- define "common.controller.volumes.v1.0.0" -}}

{{- $context := $ -}}
{{- range $storageName, $storage := .Values.storages }}
{{- if $storage.enabled }}
- name: {{ $storageName }}
  {{- if eq (default "persistentVolumeClaim" $storage.type) "persistentVolumeClaim" }}
    {{- $name := (include "common.names.fullname.v1.0.0" $context) -}}
    {{- if $storage.existingClaim }}
      {{- $name = $storage.existingClaim -}}
    {{- else -}}
    {{- if $storage.nameOverride -}}
      {{- if not (eq $storage.nameOverride "-") -}}
        {{- $name = (printf "%s-%s" (include "common.names.fullname.v1.0.0" $context) $storage.nameOverride) -}}
      {{- end -}}
    {{- else -}}
      {{- $name = (printf "%s-%s" (include "common.names.fullname.v1.0.0" $context) $storageName) -}}
    {{- end -}}
    {{- end }}
  persistentVolumeClaim:
    claimName: {{ $name }}
  {{- else if or (eq $storage.type "configMap") (eq $storage.type "secret") }}
    {{- $name := tpl (required (printf "name not set for storage item %s" $storageName) $storage.name) $ }}
    {{- if eq $storage.type "configMap" }}
  configMap:
    name: {{ $name }}
    {{- else }}
  secret:
    secretName: {{ $name }}
    {{- end }}
    {{- with $storage.defaultMode }}
    defaultMode: {{ . }}
    {{- end }}
    {{- with $storage.items }}
    items:
      {{- toYaml . | nindent 6 }}
    {{- end }}
  {{- else if eq $storage.type "emptyDir" }}
    {{- $emptyDir := dict -}}
    {{- with $storage.medium -}}
      {{- $_ := set $emptyDir "medium" . -}}
    {{- end -}}
    {{- with $storage.sizeLimit -}}
      {{- $_ := set $emptyDir "sizeLimit" . -}}
    {{- end }}
  emptyDir: {{- $emptyDir | toYaml | nindent 4 }}
  {{- else if eq $storage.type "other" }}
    {{- toYaml $storage.spec | nindent 2 }}
  {{- else }}
    {{- fail (printf "Not a valid storage.type (%s)" .Values.storages.type) }}
  {{- end }}
{{- end }}
{{- end }}
{{- if .Values.extraVolumes }}
  {{- tpl (toYaml .Values.extraVolumes) . | nindent 0 }}
{{- end }}
{{- if .Values.mountFiles -}}
{{- $chartName := .Chart.Name -}}
{{- range .Values.mountFiles }}
{{- if  (eq .type "ConfigMap") }}
- name: {{ $chartName }}-{{ .name }}-configmap-volume
  configMap:
    name: {{ $chartName }}-{{ .name }}-configmap
    {{- if .podDefaultMode }}
    defaultMode: {{ .podDefaultMode }}
    {{- end -}}
{{- else -}}
  {{- if  (eq .type "Secret") }}
- name: {{ $chartName }}-{{ .name }}-secret-volume
  secret:
    secretName: {{ $chartName }}-{{ .name }}-secret
    {{- if .podDefaultMode }}
    defaultMode: {{ .podDefaultMode }}
    {{- end -}}
  {{- else -}}
  {{- fail "type in .Values.mountFiles must be ConfigMap or Secret" }}
  {{- end }}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}