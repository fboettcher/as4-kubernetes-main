{{/* vim: set filetype=mustache: */}}
{{- define "common.labels.v1.0.0" -}}
helm.sh/chart: {{ include "common.names.chart.v1.0.0" . }}
{{ include "common.labels.selectorLabels.v1.0.0" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "common.labels.selectorLabels.v1.0.0" -}}
app.kubernetes.io/name: {{ include "common.names.name.v1.0.0" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
