# common

Helm Library Chart providing reusable building blocks to simplify the implementation of a helm chart. 

## Requirements

Kubernetes: `>=1.16.0-0`

## Configuration

Read through the [values.yaml](./values.yaml) file. It has several commented out suggested values.

## Creating a new chart

Include this chart as a dependency in your `Chart.yaml` e.g.

```yaml
# Chart.yaml
dependencies:
- name: common
  version: 1.0.0
  repository: https://nli-nexus.next-level-apps.com/repository/to-helm-nli/
```


Add the following 2 files to the `templates` folder.
```yaml
# templates/common.yaml
{{ include "common.all.v1.0.0" . }}

```


Write a `values.yaml` with some basic defaults you want to present to the user e.g.

```yaml
#
# IMPORTANT NOTE
#
# This chart inherits from our common library chart.
# https://gitlab.next-level-apps.com/t_orange/container-projects/common-library-chart
#

image:
  repository: nexus-docker.next-level-apps.com/stock-management-frontend
  tag: "1.0.0-latest"
  pullPolicy: IfNotPresent

env: {}

service:
  port:
    port: 8080
```

If testing locally make sure you update the dependencies with:

```bash
helm dependency update
```

The array **mountFiles** allows to mount local files into the container. By setting the mount type either a ConfigMap or a Secret containing the file to mount will be created. In addition the file can be set to readonly.

```yaml
# Example

mountFiles:
  - name: config
    podMountFolder: /app/assets
    podMountFileName: config.json
    podReadOnly: true
    type: ConfigMap
    localFile: config/config.json
```

If the 2 **global variables domain and protocol** are defined the building blocks **url** and **host** can be used.

```yaml
# Example

ingress:
  hosts:
    - hostTpl: '{{ include "common.host.v1.0.0" . -}}'
      ...
```

## Values

**Important**: When deploying an application Helm chart you can add more values from our common library chart [here](https://gitlab.next-level-apps.com/t_orange/container-projects/common-library-chart)

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| extraContainers | list | `[]` |  |
| extraVolumeMounts | list | `[]` |  |
| extraVolumes | list | `[]` |  |
| affinity | object | `{}` |  |
| args | list | `[]` |  |
| command | list | `[]` |  |
| annotations | object | `{}` |  |
| labels | object | `{}` |  |
| type | string | `"deployment"` |  |
| dnsPolicy | string | `"ClusterFirst"` |  |
| enableServiceLinks | bool | `true` |  |
| env | object | `{}` |  |
| envFrom | list | `[]` |  |
| envTpl | object | `{}` |  |
| envValueFrom | object | `{}` |  |
| fullnameOverride | string | `""` |  |
| hostAliases | list | `[]` |  |
| hostNetwork | bool | `false` |  |
| ingress.extraIngresses | list | `[]` |  |
| ingress.annotations | object | `{}` |  |
| ingress.enabled | bool | `false` |  |
| ingress.hosts[0].host | string | `"chart-example.local"` |  |
| ingress.hosts[0].hostTpl | string | `'{{ include "common.host.v1.0.0" . -}}'` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"Prefix"` |  |
| ingress.labels | object | `{}` |  |
| ingress.tls | list | `[]` |  |
| initContainers | list | `[]` |  |
| mountFiles  | list | `[]` |  |
| mountFiles.name | string | `""` |
| mountFiles.podMountFolder | string | `"/app/assets"` |
| mountFiles.name | string | `"config.json"` |
| mountFiles.podReadOnly | bool | `true` |
| mountFiles.type | enum | `ConfigMap or Secret` |
| mountFiles.localFile | string | `"config/config.json"` |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| persistence.config.accessModes | string | `"ReadWriteOnce"` |  |
| persistence.config.enabled | bool | `false` |  |
| persistence.config.mountPath | string | `"/config"` |  |
| persistence.config.size | string | `"1Gi"` |  |
| persistence.config.skipuninstall | bool | `false` |  |
| persistence.shared.emptyDir.enabled | bool | `true` |  |
| persistence.shared.enabled | bool | `false` |  |
| persistence.shared.mountPath | string | `"/shared"` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| probes.liveness.custom | bool | `false` |  |
| probes.liveness.enabled | bool | `true` |  |
| probes.liveness.spec.failureThreshold | int | `3` |  |
| probes.liveness.spec.initialDelaySeconds | int | `0` |  |
| probes.liveness.spec.periodSeconds | int | `10` |  |
| probes.liveness.spec.timeoutSeconds | int | `1` |  |
| probes.readiness.custom | bool | `false` |  |
| probes.readiness.enabled | bool | `true` |  |
| probes.readiness.spec.failureThreshold | int | `3` |  |
| probes.readiness.spec.initialDelaySeconds | int | `0` |  |
| probes.readiness.spec.periodSeconds | int | `10` |  |
| probes.readiness.spec.timeoutSeconds | int | `1` |  |
| probes.startup.custom | bool | `false` |  |
| probes.startup.enabled | bool | `true` |  |
| probes.startup.spec.failureThreshold | int | `30` |  |
| probes.startup.spec.initialDelaySeconds | int | `0` |  |
| probes.startup.spec.periodSeconds | int | `5` |  |
| probes.startup.spec.timeoutSeconds | int | `1` |  |
| replicaCount | int | `1` |  |
| resources | object | `{}` |  |
| secret | object | `{}` |  |
| securityContext | object | `{}` |  |
| service.extraPorts | list | `[]` |  |
| service.extraServices | list | `[]` |  |
| service.annotations | object | `{}` |  |
| service.enabled | bool | `true` |  |
| service.labels | object | `{}` |  |
| service.port.name | string | `nil` |  |
| service.port.port | string | `nil` |  |
| service.port.protocol | string | `"TCP"` |  |
| service.port.targetPort | string | `nil` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `false` |  |
| serviceAccount.name | string | `""` |  |
| strategy.type | string | `"RollingUpdate"` |  |
| tolerations | list | `[]` |  |
| volumeClaimTemplates | list | `[]` |  |