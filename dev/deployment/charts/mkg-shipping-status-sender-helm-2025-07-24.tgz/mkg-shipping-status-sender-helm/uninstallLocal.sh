#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall mkg-shipping-status-sender -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





