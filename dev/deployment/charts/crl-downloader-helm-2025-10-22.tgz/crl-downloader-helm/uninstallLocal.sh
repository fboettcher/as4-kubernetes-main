#!/bin/bash

KUBERNERNETES_NAMESPACE=crypto

helm uninstall crl-downloader -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





