#!/bin/bash

KUBERNERNETES_NAMESPACE=as4

helm uninstall hsm-simulator -n $KUBERNERNETES_NAMESPACE --kube-context docker-desktop





